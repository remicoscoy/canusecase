# Can with imposter > 2023-06-21 4:47pm
https://universe.roboflow.com/test-2lq5m/can-with-imposter

Provided by a Roboflow user
License: CC BY 4.0

