# can three training > 2023-06-23 3:40pm
https://universe.roboflow.com/test-2lq5m/can-three-training

Provided by a Roboflow user
License: CC BY 4.0

