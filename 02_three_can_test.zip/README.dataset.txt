# three cans test > 2023-06-21 4:45pm
https://universe.roboflow.com/test-2lq5m/three-cans-test

Provided by a Roboflow user
License: CC BY 4.0

